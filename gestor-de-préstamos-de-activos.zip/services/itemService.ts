
import { RawItemData, Item } from '../types';

export const processRawItems = (rawData: RawItemData[]): Item[] => {
  return rawData.map((row) => {
    const isNumeric = /^\d+$/.test(row.placa);
    return {
      uniqueKey: isNumeric ? row.placa : crypto.randomUUID(),
      placa: row.placa,
      description: row.descripcion,
      crea: row.crea,
      isConsumable: !isNumeric,
      initialQuantity: row.cantidad,
    };
  });
};