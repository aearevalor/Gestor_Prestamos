
import React, { useState, useCallback, useRef, useMemo } from 'react';
import { Item, Loan, LoanStatus } from '../types';
import SignaturePad, { SignaturePadHandle } from './SignaturePad';
import { LoanIcon, TrashIcon } from './icons';

interface LoanFormProps {
  items: Item[];
  onBatchLoan: (loans: Omit<Loan, 'id' | 'loanTimestamp' | 'receiverSignature' | 'requesterName'>[], signature: string, requesterName: string) => void;
  availableQuantities: { [uniqueKey: string]: number };
  requesters: string[];
}

const LoanForm: React.FC<LoanFormProps> = ({ items, onBatchLoan, availableQuantities, requesters }) => {
  const [loanCart, setLoanCart] = useState<{ item: Item; quantity: number | '' }[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [requesterName, setRequesterName] = useState('');
  const [receiverSignature, setReceiverSignature] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const signaturePadRef = useRef<SignaturePadHandle>(null);

  const searchResults = useMemo(() => {
    if (!searchTerm.trim()) return [];
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    return items
      .filter(item => {
        const availableQty = availableQuantities[item.uniqueKey] ?? 0;
        const inCart = loanCart.some(cartItem => cartItem.item.uniqueKey === item.uniqueKey);
        
        const isAvailable = item.isConsumable ? availableQty > 0 : (availableQty > 0 && !inCart);

        return (
          isAvailable &&
          (item.placa.toLowerCase().includes(lowerCaseSearchTerm) ||
           item.description.toLowerCase().includes(lowerCaseSearchTerm))
        );
      })
      .slice(0, 5);
  }, [searchTerm, items, availableQuantities, loanCart]);

  const handleAddItem = (item: Item) => {
    setLoanCart(prev => [...prev, { item, quantity: 1 }]);
    setSearchTerm('');
  };

  const handleRemoveItem = (uniqueKey: string) => {
    setLoanCart(prev => prev.filter(cartItem => cartItem.item.uniqueKey !== uniqueKey));
  };

  const handleQuantityChange = (uniqueKey: string, newQuantityStr: string) => {
    const itemInCart = loanCart.find(ci => ci.item.uniqueKey === uniqueKey);
    if (!itemInCart || !itemInCart.item.isConsumable) return;

    if (newQuantityStr === '') {
       setLoanCart(prev => prev.map(cartItem => (cartItem.item.uniqueKey === uniqueKey ? { ...cartItem, quantity: '' } : cartItem)));
       return;
    }
    
    const newQuantity = parseInt(newQuantityStr, 10);
    const maxAvailable = availableQuantities[itemInCart.item.uniqueKey] ?? 0;

    if (isNaN(newQuantity)) return;

    const clampedQuantity = Math.max(1, Math.min(newQuantity, maxAvailable));

    setLoanCart(prev => prev.map(cartItem =>
      cartItem.item.uniqueKey === uniqueKey ? { ...cartItem, quantity: clampedQuantity } : cartItem
    ));
  };
  
  const resetForm = useCallback(() => {
    setLoanCart([]);
    setSearchTerm('');
    setRequesterName('');
    setReceiverSignature(null);
    setFormError(null);
    signaturePadRef.current?.clear();
  }, []);

  const handleLoan = () => {
    if (loanCart.length === 0) {
      setFormError('Agregue al menos un elemento a la lista de préstamo.');
      return;
    }
    if (loanCart.some(i => i.quantity === '' || i.quantity <= 0)) {
       setFormError('Todas las cantidades deben ser números positivos.');
       return;
    }
     if (!requesterName.trim()) {
      setFormError('El nombre de quien solicita es obligatorio.');
      return;
    }
    if (!receiverSignature) {
      setFormError('La firma de quien recibe es obligatoria.');
      return;
    }
    setFormError(null);

    const loansToCreate = loanCart.map(cartItem => ({
      item: cartItem.item,
      loanedQuantity: Number(cartItem.quantity),
      returnTimestamp: null,
      returnerSignature: null,
      status: LoanStatus.LOANED,
    }));

    onBatchLoan(loansToCreate, receiverSignature, requesterName);
    resetForm();
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg h-full flex flex-col">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Registrar Nuevo Préstamo</h2>
      
      <div className="flex-grow space-y-4 flex flex-col">
        {/* Search Input */}
        <div className="relative">
          <label htmlFor="search-item" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Buscar Elemento</label>
          <input
            type="text"
            id="search-item"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por placa o descripción..."
            className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            autoComplete="off"
          />
          {searchResults.length > 0 && (
            <ul className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-700 shadow-lg rounded-md border border-gray-200 dark:border-gray-600 max-h-60 overflow-auto">
              {searchResults.map(item => (
                <li key={item.uniqueKey}>
                  <button onClick={() => handleAddItem(item)} className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-indigo-900/50">
                    <span className="font-semibold">{item.description}</span>
                    <span className="text-xs text-gray-500 dark:text-gray-400 block">Placa: {item.placa} | Disp: {availableQuantities[item.uniqueKey]}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        
        {/* Loan Cart */}
        <div className="space-y-3 pr-2 -mr-2 flex-grow overflow-y-auto">
          {loanCart.length === 0 ? (
             <p className="text-center text-sm text-gray-500 dark:text-gray-400 py-4">La lista de préstamos está vacía.</p>
          ) : (
            loanCart.map(({ item, quantity }) => (
              <div key={item.uniqueKey} className="flex items-center gap-3 bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg">
                <div className="flex-grow">
                  <p className="font-semibold text-gray-800 dark:text-gray-100">{item.description}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Placa: {item.placa}</p>
                </div>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(item.uniqueKey, e.target.value)}
                  readOnly={!item.isConsumable}
                  min="1"
                  max={item.isConsumable ? (availableQuantities[item.uniqueKey] ?? 1) : 1}
                  className={`w-20 text-center bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${!item.isConsumable ? 'cursor-not-allowed opacity-70' : ''}`}
                  aria-label={`Cantidad para ${item.description}`}
                />
                <button
                  type="button"
                  onClick={() => handleRemoveItem(item.uniqueKey)}
                  className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-red-100 dark:hover:bg-red-900/50 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                  aria-label={`Quitar ${item.description}`}
                >
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            ))
          )}
        </div>
        
        <div className="mt-auto pt-4 space-y-4">
            <div>
                <label htmlFor="requester-name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Nombre de quien solicita</label>
                <input
                    type="text"
                    id="requester-name"
                    list="requesters-list"
                    value={requesterName}
                    onChange={(e) => setRequesterName(e.target.value)}
                    placeholder="Ingrese el nombre completo"
                    className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    required
                />
                <datalist id="requesters-list">
                    {requesters.map(name => <option key={name} value={name} />)}
                </datalist>
            </div>
            <SignaturePad ref={signaturePadRef} label="Firma de quien recibe" onSave={setReceiverSignature} />
            {formError && <p className="text-sm text-red-600 dark:text-red-400 mt-2">{formError}</p>}
        </div>
      </div>

      <div className="mt-6 flex-shrink-0">
        <button
          onClick={handleLoan}
          disabled={loanCart.length === 0 || !receiverSignature || !requesterName.trim()}
          className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          <LoanIcon className="w-5 h-5" />
          Realizar Préstamo
        </button>
      </div>
    </div>
  );
};

export default LoanForm;
