
import React, { useRef, useEffect, useState, useCallback, forwardRef, useImperativeHandle } from 'react';
import { SignatureIcon, ClearIcon } from './icons';

interface SignaturePadProps {
  onSave: (signature: string) => void;
  label: string;
  disabled?: boolean;
}

export interface SignaturePadHandle {
  clear: () => void;
}

const SignaturePad = forwardRef<SignaturePadHandle, SignaturePadProps>(({ onSave, label, disabled = false }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSigned, setHasSigned] = useState(false);

  const getCtx = useCallback(() => canvasRef.current?.getContext('2d'), []);

  const getCoords = useCallback((e: React.MouseEvent | React.TouchEvent): { x: number; y: number } | null => {
    if (!canvasRef.current) return null;
    const rect = canvasRef.current.getBoundingClientRect();
    const clientX = 'touches' in e.nativeEvent ? e.nativeEvent.touches[0].clientX : e.nativeEvent.clientX;
    const clientY = 'touches' in e.nativeEvent ? e.nativeEvent.touches[0].clientY : e.nativeEvent.clientY;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  }, []);

  const startDrawing = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (disabled) return;
    const coords = getCoords(e);
    if (!coords) return;
    const ctx = getCtx();
    if (!ctx) return;
    
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    setIsDrawing(true);
    setHasSigned(true);
  }, [disabled, getCoords, getCtx]);

  const draw = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || disabled) return;
    e.preventDefault();
    const coords = getCoords(e);
    if (!coords) return;
    const ctx = getCtx();
    if (!ctx) return;
    
    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
  }, [isDrawing, disabled, getCoords, getCtx]);

  const stopDrawing = useCallback(() => {
    if (disabled) return;
    const ctx = getCtx();
    if (ctx) ctx.closePath();
    setIsDrawing(false);
    if (canvasRef.current && hasSigned) { // Only save if something was drawn
        onSave(canvasRef.current.toDataURL());
    }
  }, [disabled, onSave, getCtx, hasSigned]);

  const clearCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = getCtx();
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSigned(false);
    onSave("");
  }, [onSave, getCtx]);

  useImperativeHandle(ref, () => ({
    clear: clearCanvas,
  }));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const setCanvasStyle = () => {
      // Use documentElement for dark mode check as it's more reliable with Tailwind
      ctx.strokeStyle = document.documentElement.classList.contains('dark') ? '#D1D5DB' : '#374151';
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    };

    const observer = new ResizeObserver(() => {
        const { width, height } = canvas.getBoundingClientRect();
        if (canvas.width !== width || canvas.height !== height) {
            const tempCanvas = document.createElement('canvas');
            const tempCtx = tempCanvas.getContext('2d');
            if (tempCtx && canvas.width > 0 && canvas.height > 0) {
                tempCanvas.width = canvas.width;
                tempCanvas.height = canvas.height;
                tempCtx.drawImage(canvas, 0, 0);
            }

            canvas.width = width;
            canvas.height = height;
            setCanvasStyle();

            if (tempCtx) {
                ctx.drawImage(tempCanvas, 0, 0);
            }
        }
    });
    observer.observe(canvas);

    const themeObserver = new MutationObserver(() => {
        setCanvasStyle();
    });
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

    // Set initial style
    setCanvasStyle();

    return () => {
        observer.disconnect();
        themeObserver.disconnect();
    };
  }, []);
  
  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
      <div className={`relative w-full aspect-[2/1] bg-gray-50 dark:bg-gray-700 rounded-lg border-2 ${disabled ? 'border-dashed border-gray-300 dark:border-gray-600' : 'border-dashed border-gray-400 dark:border-gray-500'} ${disabled ? 'cursor-not-allowed' : ''}`}>
        <canvas
          ref={canvasRef}
          className={`w-full h-full rounded-lg touch-none ${disabled ? 'opacity-50' : ''}`}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
        {!hasSigned && !disabled && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400 dark:text-gray-500 pointer-events-none">
            <SignatureIcon className="w-8 h-8 mb-2" />
            <span className="text-sm">Firme aquí</span>
          </div>
        )}
         {hasSigned && !disabled && (
            <button
                type="button"
                onClick={clearCanvas}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-gray-200 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-red-100 dark:hover:bg-red-900/50 hover:text-red-600 dark:hover:text-red-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                aria-label="Limpiar firma"
            >
                <ClearIcon className="w-4 h-4" />
            </button>
        )}
      </div>
    </div>
  );
});

export default SignaturePad;
