
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Loan, LoanStatus } from '../types';
import SignaturePad, { SignaturePadHandle } from './SignaturePad';
import { ReturnIcon } from './icons';

interface LoanHistoryProps {
  loans: Loan[];
  onBatchReturn: (loanIds: string[], returnerSignature: string) => void;
}

const LoanHistory: React.FC<LoanHistoryProps> = ({ loans, onBatchReturn }) => {
  const [selectedLoanIds, setSelectedLoanIds] = useState<string[]>([]);
  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [returnerSignature, setReturnerSignature] = useState<string | null>(null);
  const signaturePadRef = useRef<SignaturePadHandle>(null);
  const modalRef = useRef<HTMLDialogElement>(null);

  const handleToggleSelection = (loanId: string) => {
    setSelectedLoanIds(prev =>
      prev.includes(loanId)
        ? prev.filter(id => id !== loanId)
        : [...prev, loanId]
    );
  };

  useEffect(() => {
    const dialog = modalRef.current;
    if (dialog) {
        if (isReturnModalOpen) {
            dialog.showModal();
        } else {
            dialog.close();
        }
    }
  }, [isReturnModalOpen]);

  const openReturnModal = () => {
    if (selectedLoanIds.length > 0) {
      setIsReturnModalOpen(true);
    }
  };

  const closeReturnModal = () => {
    setIsReturnModalOpen(false);
    setReturnerSignature(null);
    signaturePadRef.current?.clear();
  };

  const confirmReturn = () => {
    if (selectedLoanIds.length > 0 && returnerSignature) {
      onBatchReturn(selectedLoanIds, returnerSignature);
      setSelectedLoanIds([]);
      closeReturnModal();
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return 'N/A';
    return date.toLocaleString('es-ES', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const { loansOnLoan, returnedLoans, onLoanGroups, returnedGroups } = useMemo(() => {
    const onLoanItems: Loan[] = [];
    const returnedItems: Loan[] = [];
    const onLoanGrouped: { [key: string]: Loan[] } = {};
    const returnedGrouped: { [key: string]: Loan[] } = {};
    
    const sortedLoans = [...loans].sort((a, b) => b.loanTimestamp.getTime() - a.loanTimestamp.getTime());
    
    sortedLoans.forEach(loan => {
        const groupKey = loan.requesterName || 'Sin Asignar';
        if (loan.status === LoanStatus.LOANED) {
            onLoanItems.push(loan);
            if (!onLoanGrouped[groupKey]) onLoanGrouped[groupKey] = [];
            onLoanGrouped[groupKey].push(loan);
        } else {
            returnedItems.push(loan);
            if (!returnedGrouped[groupKey]) returnedGrouped[groupKey] = [];
            returnedGrouped[groupKey].push(loan);
        }
    });
    
    return { 
        loansOnLoan: onLoanItems, 
        returnedLoans: returnedItems, 
        onLoanGroups: onLoanGrouped, 
        returnedGroups: returnedGrouped 
    };
  }, [loans]);

  const LoanListItem = ({ loan, selectable }: { loan: Loan, selectable: boolean }) => (
     <div className="flex gap-4">
        {selectable && (
             <div className="flex-shrink-0 pt-1">
                <input
                    type="checkbox"
                    checked={selectedLoanIds.includes(loan.id)}
                    onChange={() => handleToggleSelection(loan.id)}
                    className="h-5 w-5 rounded border-gray-300 dark:border-gray-600 text-indigo-600 focus:ring-indigo-500 dark:bg-gray-900 dark:checked:bg-indigo-600"
                    aria-labelledby={`loan-desc-${loan.id}`}
                />
             </div>
        )}
         <div className="flex-grow">
            <span id={`loan-desc-${loan.id}`} className="sr-only">Seleccionar {loan.item.description}</span>
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold text-lg text-indigo-600 dark:text-indigo-400">{loan.item.description}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Placa: {loan.item.placa} | Cant: {loan.loanedQuantity}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Préstamo: {formatDate(loan.loanTimestamp)}</p>
                    {loan.returnTimestamp && (
                        <p className="text-xs text-gray-500 dark:text-gray-400">Devolución: {formatDate(loan.returnTimestamp)}</p>
                    )}
                </div>
                <div className="flex flex-col items-end gap-2">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${loan.status === LoanStatus.LOANED ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300' : 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300'}`}>
                            {loan.status}
                        </span>
                </div>
            </div>
             <div className="mt-3 flex gap-4 items-end">
                <div>
                    <p className="text-xs font-medium text-gray-700 dark:text-gray-300">Firma Recibe:</p>
                    <img src={loan.receiverSignature} alt="Firma de quien recibe" className="h-10 w-24 bg-white dark:bg-gray-200 rounded border border-gray-300 dark:border-gray-600 mt-1" />
                </div>
                {loan.returnerSignature && (
                    <div>
                        <p className="text-xs font-medium text-gray-700 dark:text-gray-300">Firma Entrega:</p>
                        <img src={loan.returnerSignature} alt="Firma de quien entrega" className="h-10 w-24 bg-white dark:bg-gray-200 rounded border border-gray-300 dark:border-gray-600 mt-1" />
                    </div>
                )}
            </div>
         </div>
      </div>
  );

  const LoanGroup = ({ title, loans, selectable }: { title: string; loans: Loan[], selectable: boolean}) => (
    <div>
        <h4 className="text-md font-semibold text-gray-600 dark:text-gray-400 mb-2">{title}</h4>
        <ul className="space-y-4 border-l-2 border-indigo-200 dark:border-indigo-800 pl-4 ml-1">
            {loans.map(loan => (
                <li key={loan.id} className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                     <LoanListItem loan={loan} selectable={selectable} />
                </li>
            ))}
        </ul>
    </div>
  )

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg h-full flex flex-col">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Historial de Préstamos</h2>
      
      {loansOnLoan.length > 0 && (
         <div className="mb-4 flex-shrink-0">
            <button
            onClick={openReturnModal}
            disabled={selectedLoanIds.length === 0}
            className="w-full sm:w-auto inline-flex justify-center items-center gap-2 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 dark:disabled:bg-blue-800 disabled:cursor-not-allowed transition-colors"
            >
            <ReturnIcon className="w-4 h-4" />
            Registrar Devolución de Seleccionados ({selectedLoanIds.length})
            </button>
        </div>
      )}

      <div className="overflow-y-auto flex-grow pr-2 -mr-2 space-y-6">
        {/* On Loan Section */}
        <section>
          <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3 border-b border-gray-200 dark:border-gray-700 pb-2">En Préstamo ({loansOnLoan.length})</h3>
          {Object.keys(onLoanGroups).length === 0 ? (
            <p className="text-center text-sm text-gray-500 dark:text-gray-400 py-4">No hay elementos en préstamo.</p>
          ) : (
             <div className="space-y-6">
              {Object.entries(onLoanGroups).map(([requester, loanGroup]) => (
                <LoanGroup key={requester} title={requester} loans={loanGroup} selectable={true} />
              ))}
            </div>
          )}
        </section>

        {/* Returned Section */}
        <section>
          <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3 border-b border-gray-200 dark:border-gray-700 pb-2">Devueltos ({returnedLoans.length})</h3>
          {Object.keys(returnedGroups).length === 0 ? (
             <p className="text-center text-sm text-gray-500 dark:text-gray-400 py-4">No hay devoluciones registradas.</p>
          ) : (
            <div className="space-y-6 opacity-80">
                {Object.entries(returnedGroups).map(([requester, loanGroup]) => (
                    <LoanGroup key={requester} title={requester} loans={loanGroup} selectable={false} />
                ))}
            </div>
          )}
        </section>
      </div>

       {/* Return Modal */}
        <dialog ref={modalRef} onClose={closeReturnModal} className="p-0 rounded-lg shadow-xl bg-white dark:bg-gray-800 backdrop:bg-black/50 w-11/12 max-w-lg">
            <div className="p-6">
                <h3 className="text-xl font-bold mb-4">Registrar Devolución</h3>
                <p className="mb-4 text-sm text-gray-600 dark:text-gray-300">
                    Firmando a continuación, confirma la devolución de {selectedLoanIds.length} elemento(s).
                </p>
                <SignaturePad ref={signaturePadRef} label="Firma de quien entrega" onSave={setReturnerSignature} />
                <div className="flex gap-2 mt-6">
                    <button
                        onClick={confirmReturn}
                        disabled={!returnerSignature}
                        className="flex-1 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-green-300 dark:disabled:bg-green-800 disabled:cursor-not-allowed"
                    >
                        Confirmar Devolución
                    </button>
                    <button
                        type="button"
                        onClick={closeReturnModal}
                        className="flex-1 py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        Cancelar
                    </button>
                </div>
            </div>
        </dialog>
    </div>
  );
};

export default LoanHistory;
