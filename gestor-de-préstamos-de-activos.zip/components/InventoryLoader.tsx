import React, { useState } from 'react';
import { RawItemData, Item } from '../types';
import { processRawItems } from '../services/itemService';
import { UploadIcon } from './icons';

interface InventoryLoaderProps {
  onLoad: (items: Item[]) => void;
}

const InventoryLoader: React.FC<InventoryLoaderProps> = ({ onLoad }) => {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      parseFile(file);
    }
    // Reset file input to allow re-uploading the same file
    event.target.value = '';
  };

  const parseFile = (file: File) => {
    setIsLoading(true);
    setError(null);
    const reader = new FileReader();

    /**
     * Parses a single line of CSV text, handling quoted fields containing delimiters
     * and escaped quotes.
     * @param line The CSV line to parse.
     * @param delimiter The delimiter character (e.g., ',' or ';').
     * @returns An array of strings representing the fields.
     */
    const robustCsvParser = (line: string, delimiter: string): string[] => {
      const fields: string[] = [];
      let currentField = '';
      let inQuotedField = false;

      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          if (inQuotedField && line[i + 1] === '"') {
            // This is an escaped quote ("")
            currentField += '"';
            i++; // Skip the next quote character
          } else {
            // This is a regular quote, toggle the inQuotedField state
            inQuotedField = !inQuotedField;
          }
        } else if (char === delimiter && !inQuotedField) {
          // Delimiter found outside of a quoted field
          fields.push(currentField);
          currentField = '';
        } else {
          // Regular character, append to the current field
          currentField += char;
        }
      }
      fields.push(currentField);

      // Clean up each field by trimming whitespace and removing surrounding quotes
      return fields.map(field => field.trim().replace(/^"|"$/g, '').trim());
    };

    reader.onload = (e) => {
      const text = e.target?.result as string;
      try {
        if (!text) {
          throw new Error("El archivo está vacío o no se pudo leer.");
        }

        const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
        if (lines.length < 2) {
          throw new Error("El archivo CSV está vacío o solo contiene la cabecera.");
        }
        
        let headerLine = lines[0];
        // Remove Byte Order Mark (BOM) if present
        if (headerLine.charCodeAt(0) === 0xFEFF) {
          headerLine = headerLine.slice(1);
        }

        // Detect delimiter by counting occurrences in the header
        const commas = (headerLine.match(/,/g) || []).length;
        const semicolons = (headerLine.match(/;/g) || []).length;
        const delimiter = semicolons > commas ? ';' : ',';
        
        const headers = robustCsvParser(headerLine, delimiter).map(h => h.toLowerCase());
        const requiredHeaders = ['placa', 'descripcion', 'crea', 'cantidad'];
        
        const missingHeaders = requiredHeaders.filter(rh => !headers.includes(rh));
        if (missingHeaders.length > 0) {
          throw new Error(`Faltan columnas requeridas: ${missingHeaders.join(', ')}. Verifique las cabeceras y el delimitador. Cabeceras detectadas: ${headers.join(', ')}`);
        }
        
        const placaIndex = headers.indexOf('placa');
        const descIndex = headers.indexOf('descripcion');
        const creaIndex = headers.indexOf('crea');
        const cantIndex = headers.indexOf('cantidad');

        const rawData: RawItemData[] = lines.slice(1).map((line, i) => {
          const values = robustCsvParser(line, delimiter);

          if (values.length < headers.length) {
            console.warn(`La fila ${i + 2} tiene un número de columnas incorrecto (${values.length} en lugar de ${headers.length}). Se omitirá.`);
            return null;
          }
          
          const placa = values[placaIndex] || '';
          if (!placa) {
             return null; // Silently skip empty rows
          }

          const cantidadStr = values[cantIndex] || '';
          const cantidad = parseInt(cantidadStr, 10);
          if (isNaN(cantidad)) {
             console.warn(`Cantidad inválida ('${cantidadStr}') en la fila ${i + 2} para la placa ${placa}. Se omitirá la fila.`);
             return null;
          }

          return {
            placa,
            descripcion: values[descIndex] || '',
            crea: values[creaIndex] || '',
            cantidad,
          };
        }).filter((item): item is RawItemData => item !== null);
        
        if (rawData.length === 0) {
          throw new Error("No se encontraron datos válidos en el archivo. Verifique el formato, que no esté vacío y que las filas tengan datos correctos.");
        }

        const processedItems = processRawItems(rawData); 
        onLoad(processedItems);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Ocurrió un error al procesar el archivo.");
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
      setError("No se pudo leer el archivo.");
      setIsLoading(false);
    };
    reader.readAsText(file, 'UTF-8');
  };

  return (
    <div className="max-w-lg mx-auto bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Cargar Inventario</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">Seleccione un archivo CSV para cargar el inventario. El archivo debe contener las columnas: placa, descripcion, crea, cantidad. La aplicación manejará delimitadores de coma o punto y coma, y campos entre comillas.</p>
        <label htmlFor="csv-upload" className={`w-full cursor-pointer inline-flex items-center justify-center gap-2 py-3 px-6 border border-transparent rounded-md shadow-sm text-base font-medium text-white transition-colors ${isLoading ? 'bg-indigo-400' : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'}`}>
            <UploadIcon className="w-5 h-5" />
            {isLoading ? 'Cargando...' : 'Seleccionar Archivo CSV'}
        </label>
        <input
            id="csv-upload"
            type="file"
            className="hidden"
            accept=".csv, text/csv"
            onChange={handleFileChange}
            disabled={isLoading}
        />
        {error && <p className="mt-4 text-sm text-red-600 dark:text-red-400">{error}</p>}
    </div>
  );
};

export default InventoryLoader;